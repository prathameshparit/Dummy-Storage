# obj > 2023-10-18 9:37pm
https://universe.roboflow.com/dr-d-y-patil-chaxw/obj-5mcfo

Provided by a Roboflow user
License: CC BY 4.0

